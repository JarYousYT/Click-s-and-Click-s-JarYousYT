document.getElementById('player').addEventListener("click",restarPuntos);

puntos = 40;
tiempo = 60;
necesarios = 0;
function restarPuntos(){
   puntos--;
   document.getElementById("puntos").innerHTML  = "Puntos: <b>" + puntos + "/" + necesarios +"  </b>";
  randNum  = Math.round(Math.random()*440);
  randNum2 = Math.round(Math.random()*440); document.getElementById("player").style.marginTop =randNum + "px";
document.getElementById("player").style.marginLeft =randNum2 + "px";
   if (puntos == 0) {
    alert("Win Game");
    tiempo = 60
    puntos = 40
  }
}


function restarTiempo() {
    tiempo--
   document.getElementById("tiempo").innerHTML = "&nbsp;&nbsp;&nbsp;Tiempo: "+tiempo;
   if (tiempo == 0) {
      alert("Game Over");
      tiempo = 60
      puntos = 40
   }
}

setInterval(restarTiempo,1000);

